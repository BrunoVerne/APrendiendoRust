//! Representa los posibles errores que puede producir MiniKV.
pub enum MiniKVError {
    /// La clave solicitada no existe o no tiene valor en el store.
    NotFound,

    /// Se proporcionó un argumento de más en el comando.
    ExtraArgument,

    /// El archivo `.minikv.data` tiene un formato inválido.
    InvalidDataFile,

    /// El archivo `.minikv.log` tiene un formato inválido.
    InvalidLogFile,

    /// Falta un argumento requerido en el comando.
    MissingArgument,

    /// El comando ingresado no es reconocido por MiniKV.
    UnknownCommand,

    /// Error de entrada/salida con su descripción.
    ErrorIO(String),
}

impl std::fmt::Display for MiniKVError {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        let err_type = match self {
            MiniKVError::NotFound => "NOT FOUND",
            MiniKVError::ExtraArgument => "EXTRA ARGUMENT",
            MiniKVError::InvalidDataFile => "INVALID DATA FILE",
            MiniKVError::InvalidLogFile => "INVALID LOG FILE",
            MiniKVError::MissingArgument => "MISSING ARGUMENT",
            MiniKVError::UnknownCommand => "UNKNOWN COMMAND",
            MiniKVError::ErrorIO(e) => return write!(f, "ERROR: {}", e),
        };
        write!(f, "ERROR: {}", err_type)
    }
}
